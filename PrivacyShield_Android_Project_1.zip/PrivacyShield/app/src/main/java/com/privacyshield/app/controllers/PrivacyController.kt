package com.privacyshield.app.controllers

import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.location.LocationManager
import android.media.AudioManager
import android.os.Build
import com.privacyshield.app.managers.SecurityLogManager
import com.privacyshield.app.receivers.DeviceAdminReceiver

/**
 * PrivacyController manages all privacy-related device controls.
 * Handles camera, microphone, location, and bluetooth access control.
 */
class PrivacyController(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "PrivacyControllerPrefs"
        private const val KEY_PRIVACY_MODE = "privacy_mode_active"
        private const val KEY_CAMERA_DISABLED = "camera_disabled"
        private const val KEY_MIC_BLOCKED = "mic_blocked"
        private const val KEY_LOCATION_DISABLED = "location_disabled"
        private const val KEY_BLUETOOTH_DISABLED = "bluetooth_disabled"
        private const val KEY_EMERGENCY_LOCK = "emergency_lock_active"
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val devicePolicyManager: DevicePolicyManager =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private val adminComponent: ComponentName = ComponentName(context, DeviceAdminReceiver::class.java)
    private val securityLogManager: SecurityLogManager = SecurityLogManager.getInstance(context)
    private val audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ==================== PRIVACY MODE ====================

    fun enablePrivacyMode() {
        disableCamera()
        blockMicrophone()
        disableLocation()
        disableBluetooth()
        prefs.edit().putBoolean(KEY_PRIVACY_MODE, true).apply()
        securityLogManager.logEvent("وضع الخصوصية: تم التفعيل")
    }

    fun disablePrivacyMode() {
        enableCamera()
        releaseMicrophone()
        enableLocation()
        enableBluetooth()
        prefs.edit()
            .putBoolean(KEY_PRIVACY_MODE, false)
            .putBoolean(KEY_EMERGENCY_LOCK, false)
            .apply()
        securityLogManager.logEvent("وضع الخصوصية: تم الإيقاف")
    }

    fun activateEmergencyLock() {
        disableCamera()
        blockMicrophone()
        disableLocation()
        disableBluetooth()
        prefs.edit()
            .putBoolean(KEY_PRIVACY_MODE, true)
            .putBoolean(KEY_EMERGENCY_LOCK, true)
            .apply()
        securityLogManager.logEvent("قفل الطوارئ: تم التفعيل - وضع الحماية القصوى")
    }

    fun restoreDevice() {
        enableCamera()
        releaseMicrophone()
        enableLocation()
        enableBluetooth()
        prefs.edit()
            .putBoolean(KEY_PRIVACY_MODE, false)
            .putBoolean(KEY_EMERGENCY_LOCK, false)
            .apply()
        securityLogManager.logEvent("إعادة الجهاز للوضع الطبيعي: تمت")
    }

    // ==================== CAMERA CONTROL ====================

    private fun disableCamera() {
        try {
            if (devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.setCameraDisabled(adminComponent, true)
                prefs.edit().putBoolean(KEY_CAMERA_DISABLED, true).apply()
                securityLogManager.logEvent("الكاميرا: تم التعطيل")
            }
        } catch (e: SecurityException) {
            securityLogManager.logEvent("خطأ في تعطيل الكاميرا: ${e.message}")
        }
    }

    private fun enableCamera() {
        try {
            if (devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.setCameraDisabled(adminComponent, false)
                prefs.edit().putBoolean(KEY_CAMERA_DISABLED, false).apply()
                securityLogManager.logEvent("الكاميرا: تم التفعيل")
            }
        } catch (e: SecurityException) {
            securityLogManager.logEvent("خطأ في تفعيل الكاميرا: ${e.message}")
        }
    }

    // ==================== MICROPHONE CONTROL ====================

    private fun blockMicrophone() {
        try {
            // Mute microphone using AudioManager
            audioManager.isMicrophoneMute = true
            prefs.edit().putBoolean(KEY_MIC_BLOCKED, true).apply()
            securityLogManager.logEvent("الميكروفون: تم الحجب")
        } catch (e: Exception) {
            securityLogManager.logEvent("خطأ في حجب الميكروفون: ${e.message}")
        }
    }

    private fun releaseMicrophone() {
        try {
            // Unmute microphone
            audioManager.isMicrophoneMute = false
            prefs.edit().putBoolean(KEY_MIC_BLOCKED, false).apply()
            securityLogManager.logEvent("الميكروفون: تم الإلغاء")
        } catch (e: Exception) {
            securityLogManager.logEvent("خطأ في إلغاء حجب الميكروفون: ${e.message}")
        }
    }

    // ==================== LOCATION CONTROL ====================

    private fun disableLocation() {
        try {
            prefs.edit().putBoolean(KEY_LOCATION_DISABLED, true).apply()
            securityLogManager.logEvent("الموقع: تم تعطيل الوصول (يتطلب إجراء يدوي)")
        } catch (e: Exception) {
            securityLogManager.logEvent("خطأ في تعطيل الموقع: ${e.message}")
        }
    }

    private fun enableLocation() {
        try {
            prefs.edit().putBoolean(KEY_LOCATION_DISABLED, false).apply()
            securityLogManager.logEvent("الموقع: تم إعادة التفعيل")
        } catch (e: Exception) {
            securityLogManager.logEvent("خطأ في تفعيل الموقع: ${e.message}")
        }
    }

    // ==================== BLUETOOTH CONTROL ====================

    private fun disableBluetooth() {
        try {
            val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
            if (bluetoothAdapter != null && bluetoothAdapter.isEnabled) {
                // On Android 12+ we cannot directly disable Bluetooth without user interaction
                // We record the state and notify the user
                prefs.edit().putBoolean(KEY_BLUETOOTH_DISABLED, true).apply()
                securityLogManager.logEvent("البلوتوث: تم تسجيل الحالة للحجب")
            } else {
                prefs.edit().putBoolean(KEY_BLUETOOTH_DISABLED, true).apply()
                securityLogManager.logEvent("البلوتوث: غير مفعل مسبقاً")
            }
        } catch (e: Exception) {
            securityLogManager.logEvent("خطأ في تعطيل البلوتوث: ${e.message}")
        }
    }

    private fun enableBluetooth() {
        try {
            prefs.edit().putBoolean(KEY_BLUETOOTH_DISABLED, false).apply()
            securityLogManager.logEvent("البلوتوث: تم إعادة التفعيل")
        } catch (e: Exception) {
            securityLogManager.logEvent("خطأ في تفعيل البلوتوث: ${e.message}")
        }
    }

    // ==================== STATUS QUERIES ====================

    fun isPrivacyModeActive(): Boolean = prefs.getBoolean(KEY_PRIVACY_MODE, false)

    fun isCameraDisabled(): Boolean {
        return try {
            if (devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.getCameraDisabled(adminComponent)
            } else {
                prefs.getBoolean(KEY_CAMERA_DISABLED, false)
            }
        } catch (e: Exception) {
            prefs.getBoolean(KEY_CAMERA_DISABLED, false)
        }
    }

    fun isMicrophoneBlocked(): Boolean = prefs.getBoolean(KEY_MIC_BLOCKED, false)

    fun isLocationDisabled(): Boolean = prefs.getBoolean(KEY_LOCATION_DISABLED, false)

    fun isBluetoothDisabled(): Boolean = prefs.getBoolean(KEY_BLUETOOTH_DISABLED, false)

    fun isEmergencyLockActive(): Boolean = prefs.getBoolean(KEY_EMERGENCY_LOCK, false)
}
