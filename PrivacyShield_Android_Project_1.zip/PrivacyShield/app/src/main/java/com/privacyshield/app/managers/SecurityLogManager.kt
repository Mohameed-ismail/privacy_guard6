package com.privacyshield.app.managers

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * SecurityLogManager handles local security event logging.
 * All logs are stored locally using SharedPreferences.
 * No data is sent to any external server.
 */
class SecurityLogManager private constructor(context: Context) {

    companion object {
        private const val PREFS_NAME = "SecurityLogPrefs"
        private const val KEY_LOGS = "security_logs"
        private const val MAX_LOG_ENTRIES = 500
        private const val DATE_FORMAT = "yyyy-MM-dd HH:mm:ss"

        @Volatile
        private var instance: SecurityLogManager? = null

        fun getInstance(context: Context): SecurityLogManager {
            return instance ?: synchronized(this) {
                instance ?: SecurityLogManager(context.applicationContext).also { instance = it }
            }
        }
    }

    data class LogEntry(
        val event: String,
        val timestamp: String
    )

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat(DATE_FORMAT, Locale.getDefault())

    fun logEvent(event: String) {
        val timestamp = dateFormat.format(Date())
        val newEntry = LogEntry(event = event, timestamp = timestamp)

        val logs = getLogs().toMutableList()
        logs.add(newEntry)

        // Keep only the last MAX_LOG_ENTRIES entries to prevent excessive storage
        val trimmedLogs = if (logs.size > MAX_LOG_ENTRIES) {
            logs.subList(logs.size - MAX_LOG_ENTRIES, logs.size)
        } else {
            logs
        }

        saveLogs(trimmedLogs)
    }

    fun getLogs(): List<LogEntry> {
        val logsJson = prefs.getString(KEY_LOGS, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<LogEntry>>() {}.type
            Gson().fromJson(logsJson, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clearLogs() {
        prefs.edit().remove(KEY_LOGS).apply()
    }

    private fun saveLogs(logs: List<LogEntry>) {
        val logsJson = Gson().toJson(logs)
        prefs.edit().putString(KEY_LOGS, logsJson).apply()
    }

    fun getLogCount(): Int = getLogs().size
}
