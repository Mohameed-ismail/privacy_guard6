package com.privacyshield.app.activities

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.privacyshield.app.R
import com.privacyshield.app.controllers.PrivacyController
import com.privacyshield.app.managers.SecurityLogManager
import com.privacyshield.app.receivers.DeviceAdminReceiver
import com.privacyshield.app.services.PrivacyForegroundService

class DashboardActivity : AppCompatActivity() {

    private lateinit var btnEnablePrivacy: Button
    private lateinit var btnDisablePrivacy: Button
    private lateinit var btnRestoreDevice: Button
    private lateinit var btnEmergencyLock: Button

    private lateinit var tvCameraStatus: TextView
    private lateinit var tvMicStatus: TextView
    private lateinit var tvLocationStatus: TextView
    private lateinit var tvBluetoothStatus: TextView
    private lateinit var tvPrivacyModeStatus: TextView

    private lateinit var privacyController: PrivacyController
    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private lateinit var securityLogManager: SecurityLogManager

    private val REQUEST_ENABLE_ADMIN = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, DeviceAdminReceiver::class.java)
        privacyController = PrivacyController(this)
        securityLogManager = SecurityLogManager.getInstance(this)

        initViews()
        setupClickListeners()
        checkAndRequestDeviceAdmin()
        updateStatusPanel()
    }

    override fun onResume() {
        super.onResume()
        updateStatusPanel()
    }

    private fun initViews() {
        btnEnablePrivacy = findViewById(R.id.btnEnablePrivacy)
        btnDisablePrivacy = findViewById(R.id.btnDisablePrivacy)
        btnRestoreDevice = findViewById(R.id.btnRestoreDevice)
        btnEmergencyLock = findViewById(R.id.btnEmergencyLock)

        tvCameraStatus = findViewById(R.id.tvCameraStatus)
        tvMicStatus = findViewById(R.id.tvMicStatus)
        tvLocationStatus = findViewById(R.id.tvLocationStatus)
        tvBluetoothStatus = findViewById(R.id.tvBluetoothStatus)
        tvPrivacyModeStatus = findViewById(R.id.tvPrivacyModeStatus)
    }

    private fun setupClickListeners() {
        btnEnablePrivacy.setOnClickListener {
            enablePrivacyMode()
        }

        btnDisablePrivacy.setOnClickListener {
            disablePrivacyMode()
        }

        btnRestoreDevice.setOnClickListener {
            showRestoreConfirmDialog()
        }

        btnEmergencyLock.setOnClickListener {
            activateEmergencyLock()
        }
    }

    private fun checkAndRequestDeviceAdmin() {
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            intent.putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                getString(R.string.device_admin_explanation)
            )
            startActivityForResult(intent, REQUEST_ENABLE_ADMIN)
        }
    }

    private fun enablePrivacyMode() {
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            Toast.makeText(this, getString(R.string.admin_required), Toast.LENGTH_LONG).show()
            checkAndRequestDeviceAdmin()
            return
        }

        privacyController.enablePrivacyMode()

        // Start foreground service
        val serviceIntent = Intent(this, PrivacyForegroundService::class.java)
        serviceIntent.action = PrivacyForegroundService.ACTION_START_PRIVACY
        startForegroundService(serviceIntent)

        securityLogManager.logEvent("تم تفعيل وضع الخصوصية")
        updateStatusPanel()
        Toast.makeText(this, getString(R.string.privacy_mode_enabled), Toast.LENGTH_SHORT).show()
    }

    private fun disablePrivacyMode() {
        privacyController.disablePrivacyMode()

        // Stop foreground service
        val serviceIntent = Intent(this, PrivacyForegroundService::class.java)
        serviceIntent.action = PrivacyForegroundService.ACTION_STOP_PRIVACY
        startService(serviceIntent)

        securityLogManager.logEvent("تم إيقاف وضع الخصوصية")
        updateStatusPanel()
        Toast.makeText(this, getString(R.string.privacy_mode_disabled), Toast.LENGTH_SHORT).show()
    }

    private fun showRestoreConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.restore_device_title))
            .setMessage(getString(R.string.restore_device_message))
            .setPositiveButton(getString(R.string.confirm)) { _, _ ->
                restoreDevice()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun restoreDevice() {
        privacyController.restoreDevice()

        // Stop foreground service
        val serviceIntent = Intent(this, PrivacyForegroundService::class.java)
        stopService(serviceIntent)

        securityLogManager.logEvent("تمت إعادة الجهاز للوضع الطبيعي")
        updateStatusPanel()
        Toast.makeText(this, getString(R.string.device_restored), Toast.LENGTH_SHORT).show()
    }

    private fun activateEmergencyLock() {
        if (!devicePolicyManager.isAdminActive(adminComponent)) {
            Toast.makeText(this, getString(R.string.admin_required), Toast.LENGTH_LONG).show()
            checkAndRequestDeviceAdmin()
            return
        }

        privacyController.activateEmergencyLock()

        // Start foreground service with emergency mode
        val serviceIntent = Intent(this, PrivacyForegroundService::class.java)
        serviceIntent.action = PrivacyForegroundService.ACTION_EMERGENCY_LOCK
        startForegroundService(serviceIntent)

        securityLogManager.logEvent("تم تفعيل قفل الطوارئ - وضع الحماية القصوى")
        updateStatusPanel()
        Toast.makeText(this, getString(R.string.emergency_lock_activated), Toast.LENGTH_SHORT).show()
    }

    fun updateStatusPanel() {
        val isPrivacyModeActive = privacyController.isPrivacyModeActive()
        val isCameraDisabled = privacyController.isCameraDisabled()
        val isMicBlocked = privacyController.isMicrophoneBlocked()
        val isLocationDisabled = privacyController.isLocationDisabled()
        val isBluetoothDisabled = privacyController.isBluetoothDisabled()

        // Update camera status
        updateStatusText(tvCameraStatus, isCameraDisabled)

        // Update microphone status
        updateStatusText(tvMicStatus, isMicBlocked)

        // Update location status
        updateStatusText(tvLocationStatus, isLocationDisabled)

        // Update bluetooth status
        updateStatusText(tvBluetoothStatus, isBluetoothDisabled)

        // Update privacy mode status
        if (isPrivacyModeActive) {
            tvPrivacyModeStatus.text = getString(R.string.privacy_mode_active)
            tvPrivacyModeStatus.setTextColor(getColor(R.color.status_protected))
        } else {
            tvPrivacyModeStatus.text = getString(R.string.privacy_mode_inactive)
            tvPrivacyModeStatus.setTextColor(getColor(R.color.status_unprotected))
        }
    }

    private fun updateStatusText(textView: TextView, isProtected: Boolean) {
        if (isProtected) {
            textView.text = getString(R.string.status_protected)
            textView.setTextColor(getColor(R.color.status_protected))
        } else {
            textView.text = getString(R.string.status_unprotected)
            textView.setTextColor(getColor(R.color.status_unprotected))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.dashboard_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_security_log -> {
                startActivity(Intent(this, SecurityLogActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ENABLE_ADMIN) {
            if (devicePolicyManager.isAdminActive(adminComponent)) {
                Toast.makeText(this, getString(R.string.admin_granted), Toast.LENGTH_SHORT).show()
                securityLogManager.logEvent("تم منح صلاحيات مسؤول الجهاز")
            } else {
                Toast.makeText(this, getString(R.string.admin_denied), Toast.LENGTH_LONG).show()
            }
        }
    }
}
