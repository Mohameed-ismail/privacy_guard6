package com.privacyshield.app.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.privacyshield.app.R
import com.privacyshield.app.activities.DashboardActivity
import com.privacyshield.app.managers.SecurityLogManager

/**
 * PrivacyForegroundService runs as a foreground service to maintain privacy protection.
 * Shows a persistent notification when privacy mode is active.
 * Does NOT run heavy background tasks or infinite loops.
 */
class PrivacyForegroundService : Service() {

    companion object {
        const val ACTION_START_PRIVACY = "com.privacyshield.START_PRIVACY"
        const val ACTION_STOP_PRIVACY = "com.privacyshield.STOP_PRIVACY"
        const val ACTION_EMERGENCY_LOCK = "com.privacyshield.EMERGENCY_LOCK"

        private const val CHANNEL_ID = "PrivacyShieldChannel"
        private const val CHANNEL_NAME = "PrivacyShield"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_PRIVACY -> {
                val notification = buildNotification(
                    title = getString(R.string.notification_privacy_title),
                    message = getString(R.string.notification_privacy_message),
                    isEmergency = false
                )
                startForeground(NOTIFICATION_ID, notification)
                SecurityLogManager.getInstance(this).logEvent("خدمة الخصوصية: بدأت")
            }
            ACTION_EMERGENCY_LOCK -> {
                val notification = buildNotification(
                    title = getString(R.string.notification_emergency_title),
                    message = getString(R.string.notification_emergency_message),
                    isEmergency = true
                )
                startForeground(NOTIFICATION_ID, notification)
                SecurityLogManager.getInstance(this).logEvent("خدمة الطوارئ: بدأت")
            }
            ACTION_STOP_PRIVACY -> {
                SecurityLogManager.getInstance(this).logEvent("خدمة الخصوصية: توقفت")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }

        // Return START_NOT_STICKY to avoid restarting the service unnecessarily
        // This prevents battery drain from automatic restarts
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        // Release all resources when service is destroyed
        // No microphone recording to release - we only use AudioManager.isMicrophoneMute
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_description)
            setShowBadge(false)
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun buildNotification(
        title: String,
        message: String,
        isEmergency: Boolean
    ): Notification {
        val dashboardIntent = Intent(this, DashboardActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            dashboardIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val iconRes = if (isEmergency) {
            android.R.drawable.ic_lock_lock
        } else {
            android.R.drawable.ic_secure
        }

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(iconRes)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
    }
}
