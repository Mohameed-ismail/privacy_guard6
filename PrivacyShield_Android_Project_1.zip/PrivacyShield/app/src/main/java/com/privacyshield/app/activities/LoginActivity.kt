package com.privacyshield.app.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.privacyshield.app.R
import com.privacyshield.app.managers.SecurityLogManager

class LoginActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "PrivacyShieldPrefs"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val VALID_USERNAME = "Abo@Waleed"
        private const val VALID_PASSWORD = "Abo@Waleed172839"
    }

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvError: TextView
    private lateinit var tvAppTitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if already logged in
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_IS_LOGGED_IN, false)) {
            navigateToDashboard()
            return
        }

        setContentView(R.layout.activity_login)

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvError = findViewById(R.id.tvError)
        tvAppTitle = findViewById(R.id.tvAppTitle)
    }

    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            performLogin()
        }
    }

    private fun performLogin() {
        val username = etUsername.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            showError(getString(R.string.error_empty_fields))
            return
        }

        if (username == VALID_USERNAME && password == VALID_PASSWORD) {
            // Save authentication state
            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).apply()

            // Log the login event
            SecurityLogManager.getInstance(this).logEvent("تسجيل دخول ناجح")

            tvError.visibility = View.GONE
            Toast.makeText(this, getString(R.string.login_success), Toast.LENGTH_SHORT).show()
            navigateToDashboard()
        } else {
            showError(getString(R.string.error_invalid_credentials))
            SecurityLogManager.getInstance(this).logEvent("محاولة تسجيل دخول فاشلة - اسم مستخدم: $username")
        }
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }

    private fun navigateToDashboard() {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
