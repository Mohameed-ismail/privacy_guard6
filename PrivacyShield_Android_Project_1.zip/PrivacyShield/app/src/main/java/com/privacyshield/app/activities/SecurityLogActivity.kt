package com.privacyshield.app.activities

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.privacyshield.app.R
import com.privacyshield.app.managers.SecurityLogManager

class SecurityLogActivity : AppCompatActivity() {

    private lateinit var rvLogs: RecyclerView
    private lateinit var btnClearLogs: Button
    private lateinit var tvNoLogs: TextView
    private lateinit var securityLogManager: SecurityLogManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_security_log)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.security_log_title)

        securityLogManager = SecurityLogManager.getInstance(this)

        initViews()
        loadLogs()
    }

    private fun initViews() {
        rvLogs = findViewById(R.id.rvLogs)
        btnClearLogs = findViewById(R.id.btnClearLogs)
        tvNoLogs = findViewById(R.id.tvNoLogs)

        rvLogs.layoutManager = LinearLayoutManager(this).apply {
            reverseLayout = true
            stackFromEnd = true
        }

        btnClearLogs.setOnClickListener {
            showClearConfirmDialog()
        }
    }

    private fun loadLogs() {
        val logs = securityLogManager.getLogs()
        if (logs.isEmpty()) {
            tvNoLogs.visibility = android.view.View.VISIBLE
            rvLogs.visibility = android.view.View.GONE
        } else {
            tvNoLogs.visibility = android.view.View.GONE
            rvLogs.visibility = android.view.View.VISIBLE
            val adapter = LogAdapter(logs)
            rvLogs.adapter = adapter
        }
    }

    private fun showClearConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.clear_logs_title))
            .setMessage(getString(R.string.clear_logs_message))
            .setPositiveButton(getString(R.string.confirm)) { _, _ ->
                securityLogManager.clearLogs()
                loadLogs()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Simple adapter for log entries
    inner class LogAdapter(private val logs: List<SecurityLogManager.LogEntry>) :
        RecyclerView.Adapter<LogAdapter.LogViewHolder>() {

        inner class LogViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
            val tvLogEvent: TextView = itemView.findViewById(R.id.tvLogEvent)
            val tvLogTime: TextView = itemView.findViewById(R.id.tvLogTime)
        }

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): LogViewHolder {
            val view = layoutInflater.inflate(R.layout.item_log_entry, parent, false)
            return LogViewHolder(view)
        }

        override fun onBindViewHolder(holder: LogViewHolder, position: Int) {
            val log = logs[position]
            holder.tvLogEvent.text = log.event
            holder.tvLogTime.text = log.timestamp
        }

        override fun getItemCount(): Int = logs.size
    }
}
