package com.privacyshield.app.receivers

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.privacyshield.app.R
import com.privacyshield.app.managers.SecurityLogManager

/**
 * DeviceAdminReceiver handles device administrator events.
 * Required for camera control via DevicePolicyManager.
 */
class DeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(
            context,
            context.getString(R.string.admin_enabled_message),
            Toast.LENGTH_SHORT
        ).show()
        SecurityLogManager.getInstance(context).logEvent("صلاحيات مسؤول الجهاز: تم التفعيل")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(
            context,
            context.getString(R.string.admin_disabled_message),
            Toast.LENGTH_SHORT
        ).show()
        SecurityLogManager.getInstance(context).logEvent("صلاحيات مسؤول الجهاز: تم الإلغاء")
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        SecurityLogManager.getInstance(context).logEvent("طلب إلغاء صلاحيات مسؤول الجهاز")
        return context.getString(R.string.admin_disable_warning)
    }

    override fun onPasswordChanged(context: Context, intent: Intent) {
        super.onPasswordChanged(context, intent)
        SecurityLogManager.getInstance(context).logEvent("تم تغيير كلمة مرور الجهاز")
    }
}
