# PrivacyShield - درع الخصوصية

تطبيق Android لحماية الخصوصية مبني بلغة Kotlin الأصلية.

## المتطلبات

- Android Studio Hedgehog أو أحدث
- JDK 11 أو أحدث
- Android SDK 35 (compileSdk)
- minSdkVersion: 28 (Android 9)

## هيكل المشروع

```
PrivacyShield/
├── app/
│   └── src/main/
│       ├── java/com/privacyshield/app/
│       │   ├── activities/
│       │   │   ├── MainActivity.kt          # نقطة الدخول
│       │   │   ├── LoginActivity.kt         # شاشة تسجيل الدخول
│       │   │   ├── DashboardActivity.kt     # لوحة التحكم الرئيسية
│       │   │   └── SecurityLogActivity.kt   # السجل الأمني
│       │   ├── controllers/
│       │   │   └── PrivacyController.kt     # التحكم في الخصوصية
│       │   ├── managers/
│       │   │   └── SecurityLogManager.kt    # إدارة السجلات الأمنية
│       │   ├── receivers/
│       │   │   └── DeviceAdminReceiver.kt   # مستقبل مسؤول الجهاز
│       │   └── services/
│       │       └── PrivacyForegroundService.kt  # خدمة الخلفية
│       ├── res/
│       │   ├── layout/                      # ملفات التخطيط
│       │   ├── values/                      # الموارد (ألوان، نصوص، أبعاد)
│       │   ├── drawable/                    # الأيقونات والأشكال
│       │   ├── xml/                         # إعدادات XML
│       │   └── menu/                        # قوائم التطبيق
│       └── AndroidManifest.xml
└── gradle/
    └── libs.versions.toml
```

## بيانات تسجيل الدخول

- **اسم المستخدم:** `Abo@Waleed`
- **كلمة المرور:** `Abo@Waleed172839`

> ملاحظة: تسجيل الدخول مطلوب مرة واحدة فقط بعد التثبيت.

## الميزات الرئيسية

### وضع الخصوصية
- تعطيل الكاميرا باستخدام `DevicePolicyManager.setCameraDisabled(true)`
- حجب الميكروفون باستخدام `AudioManager.isMicrophoneMute`
- تعطيل الوصول للموقع
- تعطيل البلوتوث
- خدمة مستمرة في الخلفية مع إشعار دائم

### قفل الطوارئ
- تفعيل فوري لجميع قيود الحماية
- إشعار "وضع الحماية القصوى مفعّل"

### السجل الأمني
- تسجيل جميع الأحداث الأمنية محلياً
- لا يُرسل أي بيانات للخارج
- يمكن مسح السجلات من داخل التطبيق

## بناء التطبيق

```bash
# بناء APK للتطبيق
./gradlew assembleDebug

# بناء APK للإصدار
./gradlew assembleRelease
```

## الأمان

- يعمل بالكامل دون اتصال بالإنترنت
- لا يجمع أي بيانات مستخدم
- جميع السجلات محفوظة محلياً فقط
- لا يستخدم الإنترنت (`android:usesCleartextTraffic="false"`)

## الصلاحيات المطلوبة

يطلب التطبيق صلاحيات **مسؤول الجهاز** عند أول تشغيل، وهي ضرورية للتحكم في الكاميرا.
